@extends('admin.layout.app')
@section('content')
    <div class="content-wrapper">
        <section class="content">
            <livewire:admin.chat />
        </section>
    </div>
@endsection
