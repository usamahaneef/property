<!DOCTYPE html>
<html>
<head>
    <title>Email Verification Success</title>
</head>
<body>
    <div>
        <h1>Email Verified Successfully</h1>
        <p>Your email has been successfully verified. You can now log in to your account.</p>
    </div>
</body>
</html>
